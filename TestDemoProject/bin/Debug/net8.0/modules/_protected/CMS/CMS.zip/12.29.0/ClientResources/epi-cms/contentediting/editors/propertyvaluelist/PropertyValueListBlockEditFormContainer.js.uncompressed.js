define("epi-cms/contentediting/editors/propertyvaluelist/PropertyValueListBlockEditFormContainer", [
    "dojo/_base/declare",
    "epi/shell/widget/FormContainer"
], function (
    declare,
    FormContainer
) {
    return declare([FormContainer], {
        _hideProperty: function (metadata, propertyName) {
            metadata.properties.some(function (property) {
                if (property.name === propertyName) {
                    property.showForEdit = false;
                    return true;
                }
                return false;
            });
        },

        _setMetadataAttr: function (metadata) {
            this._hideProperty(metadata, "icontent_name");
            this._hideProperty(metadata, "icategorizable_category");

            var hiddenGroupNames = ["Advanced"];
            var hiddenGroups = hiddenGroupNames.map(function (x) {
                return x.toLowerCase();
            });
            var numberOfVisibleGroups = metadata.groups.filter(function (x) {
                return x.name !== "EPiServerCMS_SettingsPanel" && hiddenGroups.indexOf(x.name.toLowerCase()) === -1;
            }).length;

            // Change group properties container to epi-cms/layout/CreateContentGroup
            metadata.layoutType = "epi/shell/layout/SimpleContainer";
            metadata.groups.forEach(function (group) {
                group.uiType = "epi-cms/layout/CreateContentGroupContainerNoHeader";

                if (group.name === "EPiServerCMS_SettingsPanel") {
                    group.options = {};
                    group.title = null;
                } else {
                    if (numberOfVisibleGroups > 1) {
                        group.uiType = "epi-cms/layout/CreateContentGroupContainer";
                    }
                }

                // by default Settings tab is not displayed
                if (hiddenGroups.indexOf(group.name.toLowerCase()) !== -1) {
                    group.displayUI = false;
                }
            });
            this._set("metadata", metadata);
        }
    });
});
